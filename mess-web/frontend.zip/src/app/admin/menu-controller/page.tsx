"use client";

import { useState, useEffect } from "react";
import { Save, Plus, Edit2, Trash2, ChevronDown, Loader2 } from "lucide-react";
import API from "@/lib/api"; // Your configured Axios instance
import Toast from "@/components/student/Toast"; // Assuming you have this

// Match this to your backend's Mongoose Model
interface MenuItem {
  _id: string;
  day: number; // 0=Sunday, 1=Monday... or string depending on your DB
  mealType: number; // 1=Breakfast, 2=Lunch, 3=Dinner
  items: string;
}

export default function MenuControlPage() {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<{ show: boolean; msg: string; type: "success" | "error" } | null>(null);

  // --- 1. FETCH REAL DATA ---
  const fetchMenu = async () => {
    setLoading(true);
    try {
      // Assuming you have an endpoint that gets the full weekly menu for the admin
      // If you only have day-by-day, you might need to adjust this endpoint!
      const res = await API.get("/menu/all"); 
      
      // Ensure it's an array
      const data = Array.isArray(res.data.data) ? res.data.data : [];
      
      // Optional: Sort by Day (0-6) and then by MealType (1-3) so it looks organized in the table
      const sortedData = data.sort((a: { day: number; mealType: number; }, b: { day: number; mealType: number; }) => {
        if (a.day !== b.day) return a.day - b.day;
        return a.mealType - b.mealType;
      });

      setMenuItems(sortedData);
    } catch (error) {
      console.error("Failed to fetch menu:", error);
      setToast({ show: true, msg: "Failed to load menu from server", type: "error" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMenu();
  }, []);

  // --- 2. DELETE HANDLER ---
  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this meal?")) return;
    
    try {
      await API.delete(`/menu/delete/${id}`); // Adjust endpoint to match your backend
      setToast({ show: true, msg: "Meal deleted successfully", type: "success" });
      fetchMenu(); // Refresh the table
    } catch (error) {
      setToast({ show: true, msg: "Failed to delete meal", type: "error" });
    }
  };

  // --- HELPERS FOR UI ---
  const getDayName = (dayNum: number) => {
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    return days[dayNum] || dayNum;
  };

  const getMealName = (type: number) => {
    if (type === 1) return "Breakfast";
    if (type === 2) return "Lunch";
    if (type === 3) return "Dinner";
    return "Unknown";
  };

  return (
    <div className="p-6 sm:p-8 max-w-7xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Menu Control</h1>
          <p className="text-gray-500 text-sm mt-1">Edit and manage weekly meal menus</p>
        </div>
        <button className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-all shadow-sm active:scale-95">
          <Save className="h-4 w-4" />
          Save All Changes
        </button>
      </div>

      {/* Filter Card */}
      <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm flex items-center gap-4">
        <span className="text-sm font-semibold text-gray-900">Select Hostel:</span>
        <div className="relative">
          <select className="appearance-none bg-orange-50/50 border border-orange-100 text-gray-800 text-sm rounded-lg pl-4 pr-10 py-2 focus:outline-none focus:ring-2 focus:ring-orange-200 cursor-pointer font-medium">
            <option>All Hostels</option>
            <option>Boys Hostel A</option>
            <option>Girls Hostel B</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-orange-600 pointer-events-none" />
        </div>
        <span className="bg-blue-50 text-blue-600 text-xs font-semibold px-3 py-1.5 rounded-md">
          Changes will apply to all hostels
        </span>
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        
        {/* Table Header Controls */}
        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-lg font-bold text-gray-900">Weekly Menu Schedule</h2>
          <button className="flex items-center gap-2 bg-white border border-orange-200 text-orange-700 hover:bg-orange-50 px-4 py-2 rounded-lg text-sm font-semibold transition-all">
            <Plus className="h-4 w-4" />
            Add Menu Item
          </button>
        </div>

        {/* Table */}
        <div className="overflow-x-auto min-h-75">
          {loading ? (
             <div className="flex flex-col items-center justify-center h-64 text-gray-400 gap-3">
               <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
               <p>Loading menu from database...</p>
             </div>
          ) : menuItems.length === 0 ? (
             <div className="flex flex-col items-center justify-center h-64 text-gray-400">
               <p>No menu items found. Add some to get started!</p>
             </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50/50">
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider w-32">Day</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider w-40">Meal</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Menu Items</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right w-24">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {menuItems.map((item) => (
                  <tr key={item._id} className="hover:bg-gray-50/50 transition-colors group">
                    <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                      {getDayName(item.day)}
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-block px-3 py-1 text-xs font-bold text-orange-700 bg-white border border-orange-200 rounded-md shadow-sm">
                        {getMealName(item.mealType)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600 font-medium">
                      {item.items.split(',').join(' • ')} {/* Makes comma-separated items look nicer */}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="text-gray-400 hover:text-blue-600 transition-colors" title="Edit">
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button 
                          onClick={() => handleDelete(item._id)}
                          className="text-gray-400 hover:text-red-600 transition-colors" 
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
      
      {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      <div className="h-10"></div>
    </div>
  );
}