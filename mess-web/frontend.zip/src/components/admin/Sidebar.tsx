"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { 
  LayoutDashboard, Users, CalendarCheck, 
  Inbox, UtensilsCrossed, Store, 
  Settings, LogOut, Menu
} from "lucide-react";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = () => {
    router.push("/auth/logut");
  };

  const navItems = [
    { name: "Dashboard", icon: LayoutDashboard, path: "/admin/dashboard" },
    { name: "Students", icon: Users, path: "/admin/students" },
    { name: "Attendance", icon: CalendarCheck, path: "/admin/attendance" },
    { name: "Smart Inbox", icon: Inbox, path: "/admin/inbox", badge: 12 },
    { name: "Menu Control", icon: UtensilsCrossed, path: "/admin/menu-controller" },
    { name: "Vendors", icon: Store, path: "/admin/vendors" },
    { name: "Settings", icon: Settings, path: "/admin/settings" },
  ];

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden font-sans">
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col md:flex">

        <div className="h-20 flex items-center px-6 border-b border-gray-100">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gray-900 text-white shadow-sm mr-3">
            <span className="font-bold text-lg">M</span>
          </div>
          <div>
            <h1 className="text-lg font-bold leading-tight text-gray-900">MessMate</h1>
            <p className="text-xs text-gray-500 font-medium">Admin Portal</p>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1 scrollbar-hide">
          {navItems.map((item) => {
            const isActive = pathname.startsWith(item.path);
            return (
              <Link
                key={item.name}
                href={item.path}
                className={`flex items-center justify-between px-3 py-2.5 rounded-lg transition-colors text-sm font-medium ${
                  isActive 
                    ? "bg-blue-50 text-blue-700" 
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                }`}
              >
                <div className="flex items-center gap-3">
                  <item.icon className={`h-5 w-5 ${isActive ? "text-blue-600" : "text-gray-400"}`} />
                  {item.name}
                </div>
                {item.badge && (
                  <span className="bg-orange-100 text-orange-600 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </div>

        {/* User Profile & Logout */}
        <div className="border-t border-gray-200 p-4">
          <div className="flex items-center gap-3 mb-4 px-2">
            <div className="h-10 w-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">
              SA
            </div>
            <div>
              <p className="text-sm font-bold text-gray-900">Super Admin</p>
              <p className="text-xs text-gray-500">admin@university.edu</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium text-gray-600 hover:bg-red-50 hover:text-red-700 rounded-lg transition-colors border border-gray-100"
          >
            <LogOut className="h-5 w-5 text-gray-400" />
            Logout
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header (Hidden on Desktop) */}
        <div className="md:hidden h-16 bg-white border-b border-gray-200 flex items-center px-4">
            <Menu className="h-6 w-6 text-gray-600" />
            <span className="ml-3 font-bold text-gray-900">MessMate Admin</span>
        </div>
        
        {/* Page Content injected here */}
        <div className="flex-1 overflow-y-auto bg-[#F8FAFC]">
            {children}
        </div>
      </main>
    </div>
  );
}