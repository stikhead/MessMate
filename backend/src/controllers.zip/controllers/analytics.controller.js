import asyncHandler from "../utils/asyncHandler";

const getWastageReport = asyncHandler(async(req, res)=>{

})

const getStudentSpending = asyncHandler(async(req, res)=>{

})

const getWorstRatedMeal = asyncHandler(async(req, res)=>{

})

export {getStudentSpending, getWastageReport, getWorstRatedMeal};