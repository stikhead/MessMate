import "dotenv/config"
import Razorpay from "razorpay";

export const {DB_NAME} = "mess_management";

